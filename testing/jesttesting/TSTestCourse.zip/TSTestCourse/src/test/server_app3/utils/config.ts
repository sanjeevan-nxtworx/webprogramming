process.env.HOST = 'some.host';
process.env.PORT = '1234';