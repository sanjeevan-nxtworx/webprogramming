

export type Reservation = {
    id: string,
    room: string,
    user: string,
    startDate: string,
    endDate: string
}